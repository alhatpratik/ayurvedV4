package project.model;

import java.util.List;

import project.Entity.Patient;

public class ListCIPD {
	
	List<Patient> list;

	public List<Patient> getList() {
		return list;
	}

	public void setList(List<Patient> list) {
		this.list = list;
	}

}

package project.model;

import org.springframework.stereotype.Component;

public class Sub_login {
	
	
	String uname;
	String password;
	
	
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	

}
